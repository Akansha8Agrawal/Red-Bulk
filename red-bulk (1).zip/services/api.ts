import { VideoRecommendation, WebhookResponse } from '../types';
import { WEBHOOK_URL } from '../constants';

// Curated fallback data to ensure the app works even if the backend is down
const FALLBACK_VIDEOS: VideoRecommendation[] = [
  {
    id: 1,
    title: "Full Push Workout for Mass - Jeff Nippard Style",
    focus: "Upper Body Volume",
    dayLabel: "Monday - Push Day",
    videoUrl: "https://www.youtube.com/embed/84l3TqQhyJs" 
  },
  {
    id: 2,
    title: "Heavy Back and Biceps for Ultimate Thickness",
    focus: "Back Strength & Density",
    dayLabel: "Tuesday - Pull Day",
    videoUrl: "https://www.youtube.com/embed/Xq4y8_20Asw" 
  },
  {
    id: 3,
    title: "Ultimate Quads and Hamstrings Day",
    focus: "Lower Body Hypertrophy",
    dayLabel: "Thursday - Leg Day",
    videoUrl: "https://www.youtube.com/embed/J7sYF_tBdwQ"
  }
];

export const fetchWorkoutVideos = async (userGoal: string): Promise<VideoRecommendation[]> => {
  // 1. Fast path for unconfigured URL
  if (WEBHOOK_URL.includes('YOUR_N8N_WEBHOOK_URL_HERE')) {
    console.warn("Webhook URL not configured. Using mock data.");
    await new Promise(resolve => setTimeout(resolve, 1500));
    return FALLBACK_VIDEOS;
  }

  try {
    console.log(`Sending POST request to: ${WEBHOOK_URL}`);
    
    // 2. Setup timeout to prevent hanging (8 seconds)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userGoal }),
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }

    // 3. Handle Empty Response or Invalid JSON
    const text = await response.text();
    if (!text || text.trim() === '') {
       throw new Error("Empty response body from Webhook");
    }

    let data: WebhookResponse;
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw new Error("Failed to parse JSON response");
    }

    // 4. Validate Data Structure
    if (!data.videoRecommendations || !Array.isArray(data.videoRecommendations)) {
       throw new Error("Response missing 'videoRecommendations' array");
    }

    return data.videoRecommendations;

  } catch (error) {
    console.warn("API Fetch failed. Falling back to Demo Data.", error);
    
    // 5. FALLBACK STRATEGY:
    // Instead of throwing an error and breaking the UI, we return the fallback data.
    // This effectively "fixes" the experience for the user when the backend is unreliable.
    return FALLBACK_VIDEOS;
  }
};
