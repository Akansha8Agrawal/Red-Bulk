import React, { useState } from 'react';
import { Play, Zap } from 'lucide-react';
import { PRESET_GOALS } from '../constants';

interface GoalInputProps {
  onSubmit: (goal: string) => void;
}

const GoalInput: React.FC<GoalInputProps> = ({ onSubmit }) => {
  const [goal, setGoal] = useState('');

  const handlePresetClick = (text: string) => {
    setGoal(text);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (goal.trim()) {
      onSubmit(goal);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-2xl px-4 mx-auto animate-fade-in">
      <div className="w-full mb-8 text-center">
        <h2 className="text-4xl font-bold text-white mb-2">What’s Your <span className="text-red-600">Red Bulk</span> Goal?</h2>
        <p className="text-gray-400">Define your target. We curate the intensity.</p>
      </div>

      <form onSubmit={handleSubmit} className="w-full space-y-6">
        <div className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-red-600 to-red-900 rounded-2xl blur opacity-30 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
          <textarea
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="Describe your training goal here..."
            className="relative w-full p-6 text-xl text-white bg-gray-900 border-2 border-gray-700 rounded-xl focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 placeholder-gray-600 transition-all shadow-2xl min-h-[160px] resize-none"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {PRESET_GOALS.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handlePresetClick(preset.text)}
              className="flex items-center justify-center px-4 py-3 text-sm font-semibold text-white transition-all bg-gray-800 border border-red-900/30 rounded-lg hover:bg-gray-700 hover:border-red-600 hover:shadow-[0_0_15px_rgba(220,38,38,0.3)] group"
            >
              <Zap className="w-4 h-4 mr-2 text-red-600 group-hover:text-yellow-400 transition-colors" />
              {preset.label}
            </button>
          ))}
        </div>

        <button
          type="submit"
          disabled={!goal.trim()}
          className={`w-full py-5 text-xl font-bold text-white uppercase tracking-wider transition-all rounded-xl shadow-lg
            ${goal.trim() 
              ? 'bg-red-600 hover:bg-red-700 hover:shadow-red-600/40 transform hover:-translate-y-1' 
              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
            }
          `}
        >
          <span className="flex items-center justify-center">
            Find My Workout Videos
            <Play className="w-6 h-6 ml-3 fill-current" />
          </span>
        </button>
      </form>
    </div>
  );
};

export default GoalInput;
