import React, { useEffect, useState } from 'react';
import { VideoRecommendation } from '../types';
import { PlayCircle, Calendar, Target } from 'lucide-react';

interface VideoPlayerProps {
  recommendations: VideoRecommendation[];
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ recommendations }) => {
  const [activeVideo, setActiveVideo] = useState<VideoRecommendation | null>(null);

  useEffect(() => {
    if (recommendations.length > 0) {
      setActiveVideo(recommendations[0]);
    }
  }, [recommendations]);

  if (!activeVideo) return null;

  return (
    <div className="flex flex-col w-full max-w-7xl mx-auto animate-fade-in p-4 lg:p-6 gap-8">
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-full">
        {/* Component A: Main YouTube Player */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          <div className="relative w-full pt-[56.25%] bg-black rounded-2xl overflow-hidden shadow-2xl shadow-red-900/20 border border-gray-800">
            <iframe
              src={activeVideo.videoUrl}
              title={activeVideo.title}
              className="absolute top-0 left-0 w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <div className="p-4 bg-gray-800/50 rounded-xl border border-gray-800">
             <div className="flex items-center space-x-2 mb-2">
                <span className="px-3 py-1 text-xs font-bold text-black bg-yellow-400 rounded-full uppercase">
                  Now Playing
                </span>
                <span className="text-sm font-semibold text-red-400 flex items-center">
                  <Calendar className="w-3 h-3 mr-1" />
                  {activeVideo.dayLabel}
                </span>
             </div>
             <h2 className="text-2xl font-bold text-white">{activeVideo.title}</h2>
             <p className="text-gray-400 mt-1 flex items-center">
                <Target className="w-4 h-4 mr-2 text-gray-500" />
                Focus: {activeVideo.focus}
             </p>
          </div>
        </div>

        {/* Component B: Scrollable Recommendation List */}
        <div className="lg:col-span-1 flex flex-col h-full min-h-[400px] lg:h-auto">
          <h3 className="text-lg font-bold text-gray-300 mb-4 px-1 uppercase tracking-wider">
            Your Rotation
          </h3>
          <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar max-h-[600px]">
            {recommendations.map((video) => (
              <div
                key={video.id}
                onClick={() => setActiveVideo(video)}
                className={`
                  group cursor-pointer p-4 rounded-xl border-l-4 transition-all duration-300
                  ${activeVideo.id === video.id 
                    ? 'bg-gray-800 border-red-600 shadow-lg shadow-black/40' 
                    : 'bg-gray-900 border-gray-700 hover:bg-gray-800 hover:border-red-500/50'
                  }
                `}
              >
                <div className="flex items-start justify-between">
                   <div className="flex-1">
                      <h4 className={`font-semibold text-sm mb-1 line-clamp-2 ${activeVideo.id === video.id ? 'text-white' : 'text-gray-300 group-hover:text-white'}`}>
                        {video.title}
                      </h4>
                      <p className="text-xs text-red-500 font-medium mb-1">
                        {video.dayLabel}
                      </p>
                      <p className="text-xs text-gray-500">
                        {video.focus}
                      </p>
                   </div>
                   {activeVideo.id === video.id && (
                     <PlayCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
                   )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
