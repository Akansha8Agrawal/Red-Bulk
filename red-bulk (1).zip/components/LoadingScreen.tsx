import React from 'react';
import { Loader2 } from 'lucide-react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-[60vh] text-center px-4">
      <div className="relative">
        <div className="absolute inset-0 bg-red-600 rounded-full blur-xl opacity-20 animate-pulse"></div>
        <Loader2 className="w-20 h-20 text-red-600 animate-spin relative z-10" />
      </div>
      <h2 className="mt-8 text-2xl font-bold text-white animate-pulse">
        Curating Videos from n8n...
      </h2>
      <p className="mt-2 text-gray-500">Analyzing hypertrophy parameters</p>
    </div>
  );
};

export default LoadingScreen;
