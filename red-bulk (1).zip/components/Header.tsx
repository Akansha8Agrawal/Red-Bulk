import React from 'react';
import { Dumbbell } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-center py-6 border-b border-gray-800 bg-gray-900/50 sticky top-0 z-10 backdrop-blur-md">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-red-600 rounded-lg shadow-lg shadow-red-600/20">
          <Dumbbell className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-extrabold tracking-tighter text-white">
          RED <span className="text-red-600">BULK</span>
        </h1>
      </div>
    </header>
  );
};

export default Header;
